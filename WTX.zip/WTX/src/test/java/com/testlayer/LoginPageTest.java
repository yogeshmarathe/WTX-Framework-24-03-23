package com.testlayer;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.wtx.testbase.TestBase;

public class LoginPageTest extends TestBase{
	
	@Test
	public void VerifyLogin() {
		String actresult = driver.getCurrentUrl();
		String expresult = "https://develop.d4ihzrgkneav4.amplifyapp.com/";
		Assert.assertEquals(expresult, actresult);
	}
	
	

}
