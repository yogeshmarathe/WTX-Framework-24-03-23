package com.wtx.testbase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.wtx.pagelayer.LoginPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestBase {
	public static WebDriver driver;
	public LoginPage Login;
	
	public void setup() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://develop.d4ihzrgkneav4.amplifyapp.com/login");
		
		Login.enteremail("yogesh@neetable.com");
		Login.enterpassword("AmrRoh@123");
		Login.clickonloginbtn();
		
	}
	

}
