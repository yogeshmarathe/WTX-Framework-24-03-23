package com.wtx.pagelayer;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.wtx.testbase.TestBase;

public class LoginPage extends TestBase{
	
	public void LoginPage() {
		PageFactory.initElements(driver, this);
		}
	
	@FindBy(xpath="//input[@name='email']")
	private WebElement email_text;
	@FindBy(xpath="//input[@name='password']")
	private WebElement Password;
	@FindBy(xpath="//button[text()='Login']")
	private WebElement Login_Btn;
	
	public void enteremail(String email) {
		email_text.sendKeys(email);
	}
	public void enterpassword(String pass) {
		Password.sendKeys(pass);
	}
	public void clickonloginbtn() {
		Login_Btn.click();
	}
	



}
